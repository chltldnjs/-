# Design System Strategy: Tactical Noir & The Red Pulse

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Tactical Monolith."** 

We are moving away from the "friendly SaaS" aesthetic toward a high-stakes, elite football analysis environment. Imagine the tension of a tunnel before a match—the deep shadows of the stadium, the precision of tactical whiteboards, and the sudden, electric jolt of Manchester United Red. This system is designed to feel like a premium broadcast tool used by top-tier analysts, but infused with the raw energy of the Stretford End.

To break the "template" look, we utilize **Intentional Asymmetry**. Layouts should feel weighted and deliberate, using high-contrast typography scales and overlapping elements (like a player’s heat map bleeding over a container edge) to create a sense of depth and kinetic energy.

## 2. Colors & Surface Architecture

The palette is rooted in "Pitch Noir"—a spectrum of deep grays and blacks that provide a void-like canvas for the high-energy red.

*   **The Primary Pulse:** `#DA291C` (Primary Container) is our heat. It is reserved for high-importance actions, critical live updates (e.g., a "Goal" alert), and brand-critical moments. Use the `primary` token (`#ffb4a8`) for subtle highlights or text on dark backgrounds to ensure legibility without losing the "red" essence.
*   **The "No-Line" Rule:** We do not use 1px solid borders to separate sections. Sectioning is achieved through **Tonal Transitions**. A section sitting on `surface` (`#131313`) should transition to `surface-container-low` (`#1c1b1b`) to denote a change in content.
*   **Surface Hierarchy & Nesting:** Treat the UI as a physical stack.
    *   **Base:** `surface-container-lowest` (`#0e0e0e`) for the deepest background.
    *   **Level 1:** `surface` (`#131313`) for main content areas.
    *   **Level 2:** `surface-container-high` (`#2a2a2a`) for interactive cards.
*   **The "Glass & Gradient" Rule:** For floating tactical overlays, use `surface` colors at 70% opacity with a `24px` backdrop blur. To add "soul" to buttons or hero sections, use a subtle linear gradient from `primary` (`#ffb4a8`) to `primary_container` (`#da291c`) at a 135-degree angle.

## 3. Typography: The Editorial Voice

We use **Manrope** exclusively. Its geometric yet modern construction allows it to scale from technical data points to aggressive editorial headlines.

*   **Display & Headline:** Use `display-lg` (3.5rem) for singular, high-impact stats (e.g., "90+5'"). These should be bold and unapologetic. 
*   **Title & Body:** Use `title-lg` for section headers. `body-md` is your workhorse for analysis text. Ensure `on_surface_variant` (`#e6bdb7`) is used for secondary information to maintain a high-end, muted contrast against the noir background.
*   **Functional Labels:** `label-sm` should be used for technical data (xG, Heatmap coordinates, Distance covered). These are the "metadata" of the game and should feel like fine print on a luxury watch.

## 4. Elevation & Depth: Tonal Layering

Traditional drop shadows are too "web 2.0" for this system. We define depth through light and material.

*   **The Layering Principle:** Instead of a shadow, place a `surface-container-highest` card on top of a `surface` background. The subtle shift in gray creates a sophisticated, "lit from within" effect.
*   **Ambient Shadows:** If an element must float (e.g., a tactical modal), use an ultra-diffused shadow. 
    *   *Value:* `0px 24px 48px rgba(0, 0, 0, 0.4)`. The shadow color must never be pure black; it should be a deep tint of the background color.
*   **The "Ghost Border":** For elements that require a boundary (like input fields), use the `outline-variant` (`#5c403b`) at 20% opacity. It should be felt, not seen.
*   **Glassmorphism:** Use it for navigation bars and tactical sidebars. This allows the "Pitch Noir" background to bleed through, ensuring the app feels like one cohesive unit rather than fragmented boxes.

## 5. Components

*   **Buttons:**
    *   *Primary:* Solid `primary_container` (#da291c) with `on_primary_container` text. Use `xl` (0.75rem) roundedness for a modern, "pill-lite" feel.
    *   *Secondary:* Ghost style. No background, `outline` border at 20% opacity, with `primary` text.
*   **Cards:** Strictly forbid dividers. Use vertical white space and `surface-container` shifts to separate the header from the body.
*   **Tactical Chips:** Use `secondary_container` (#474746) for inactive states and `primary_container` (#da291c) for active selections. They should be small, sharp, and functional.
*   **Input Fields:** Use `surface_container_lowest` (#0e0e0e) for the field background to create an "etched into the pitch" look. Use the red `primary` for the active cursor and focus state.
*   **Data Visualizations (Custom):** For player stats, use a "Pulse" line chart using the `primary` color. For heatmaps, transition from `surface_container` (cold) to `primary_container` (hot).

## 6. Do's and Don'ts

**Do:**
*   Use `surface_bright` (#3a3939) for hover states on dark cards to create a "lifting" effect.
*   Maintain aggressive white space. If you think there's enough room, add 16px more.
*   Use the `primary` red sparingly. It is a precision tool, not a paint bucket.

**Don't:**
*   **No Dividers:** Never use a 1px line to separate list items. Use a 4px gap and a subtle `surface-container-low` background on the item itself.
*   **No Pure White:** Use `on_surface` (#e5e2e1) for text. Pure white (#FFFFFF) is too harsh for the "Pitch Noir" environment and ruins the premium feel.
*   **No Standard Grids:** Experiment with offsetting your "Headline" from the "Body" text by 1 or 2 columns to create an editorial, magazine-style flow.

**Director's Final Note:** 
Every pixel should feel like it was placed by a tactician. If a design choice doesn't make the data look more "elite" or the action feel more "passionate," strip it away. We are building a monolith—solid, powerful, and unmistakably United.